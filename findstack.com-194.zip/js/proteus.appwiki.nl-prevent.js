'use strict';

(function () {

  if (!window.location.hostname || window.location.hostname === 'localhost') {
    return;
  }

  var cssNeedsInjecting = true;
  var counter = 0;

  var attemptCssInjection = function () {
    counter++;

    if (document.querySelectorAll("[class^='js-appwiki-']").length === 0) {
      return;
    }

    var proteusHostName = window.proteusHostName || 'https://proteus.appwiki.nl';
    var script = document.createElement('link');
    script.rel = 'stylesheet';
    script.href =
      proteusHostName +
      '/v1/css?host=' +
      window.location.hostname +
      '&page=' +
      window.location.pathname;

    (document.head || document.body).appendChild(script);

    cssNeedsInjecting = false;
  };

  attemptCssInjection();

  var interval = setInterval(() => {
    cssNeedsInjecting ? attemptCssInjection() : clearInterval(interval);

    if (counter > 12) {
      cssNeedsInjecting = false;
    }
  }, 50);

  window.onload = function () {
    cssNeedsInjecting = false;
  };
})();

if (!window.mvfProteus) {
  window.mvfProteus = {
    MIN_EL_HEIGHT: 1,
    MAX_EL_HEIGHT: 10000,
    PROTEUS_HOST: window.proteusHostName || 'https://proteus.appwiki.nl',
    MEASUREMENTS_URI: '/v1/measurements',
    CSS_URI: '/v1/css',
    CLS_EVENT: 'CLSAwareContentLoaded',
    IMPLEMENTATION_HOST: undefined,
    IMPLEMENTATION_PAGE: undefined,
    CLS_READY_CLASS: 'cls-content-loaded',
    CLS_SNAPSHOT_TAKEN_CLASS: 'cls-snapshot-taken',

    /**
     * @param {Element} element
     * @return {boolean}
     * @private
     */
    _elementsIsUpForMeasurement: function _elementsIsUpForMeasurement(element) {
      if (!this._elementIsInViewport(element)) {
        return false;
      }

      if (!this._elementIsLargeEnough(element)) {
        return false;
      }

      return true;
    },

    /**
     * @param {Element} element
     * @returns {boolean}
     */
    _elementIsInViewport: function _elementIsInViewport(element) {
      return element.getBoundingClientRect().top < window.innerHeight;
    },

    /**
     * @param {Element} element
     * @returns {boolean}
     */
    _elementIsLargeEnough: function _elementIsLargeEnough(element) {
      return (
        this.MIN_EL_HEIGHT < element.getBoundingClientRect().height &&
        element.getBoundingClientRect().height < this.MAX_EL_HEIGHT
      );
    },

    /**
     * Selector should be either a class or id selector with a data attribute.
     *
     * @param {string} selector
     * @returns {boolean}
     */
    _elementSelectorIsUniqueEnough: function _elementSelectorIsUniqueEnough(selector) {
      return new RegExp(
        /[\.\#]-?[_a-zA-Z0-9-]*\[-?[_a-zA-Z0-9-]*="-?[_a-zA-Z0-9-]*"\]-?[_a-zA-Z0-9-]*/gm,
      ).test(selector);
    },

    /**
     * @param {Element} element
     * @returns {int}
     */
    _getElementHeight: function _getElementHeight(element) {
      var rect = element.getBoundingClientRect();
      return parseInt(rect.height);
    },

    /**
     * @param {string} selector
     */
    _storeMeasurement: function _storeMeasurement(selector) {
      var _this = this;

      if (!this._elementSelectorIsUniqueEnough(selector)) {
        return;
      }

      var element = document.querySelector(selector);

      if (!this.IMPLEMENTATION_HOST) {
        return;
      }

      if (this._elementIsMarkedAsRendered(element)) {
        return;
      }

      if (element !== null && this._elementsIsUpForMeasurement(element)) {
        this._markElementAsRendered(element);

        const body = {
          selector: selector,
          viewportWidth: parseInt(window.innerWidth),
          elementHeight: this._getElementHeight(element),
          host: this.IMPLEMENTATION_HOST,
        };

        if (this.IMPLEMENTATION_PAGE) {
          body.page = this.IMPLEMENTATION_PAGE;
        }

        fetch(this.PROTEUS_HOST + this.MEASUREMENTS_URI, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        })
          .then(function (res) {
            _this._markSnapshotTaken(element);
          })
          .catch(function () {
            _this._markSnapshotTaken(element);
          });
      }
    },

    _setHostAndPage: function _setHostAndPage() {
      var styleElement = document.querySelector(
        'link[href*="' + this.PROTEUS_HOST + '"][href*="' + this.CSS_URI + '"]',
      );
      if (styleElement) {
        var href = styleElement.getAttribute('href');
        var url = new URL(href);
        var urlParams = new URLSearchParams(url.search);
        this.IMPLEMENTATION_HOST = urlParams.get('host');
        this.IMPLEMENTATION_PAGE = urlParams.get('page') || undefined;
      }
    },

    /**
     * @param {Element} element
     */
    _markElementAsRendered: function _markElementAsRendered(element) {
      element.classList.add(this.CLS_READY_CLASS);
    },

    /**
     * @param {Element} element
     */
    _markSnapshotTaken: function _markSnapshotTaken(element) {
      element.classList.add(this.CLS_SNAPSHOT_TAKEN_CLASS);
    },

    /**
     * @param {Element} element
     */
    _elementIsMarkedAsRendered: function _elementIsMarkedAsRendered(element) {
      return element.classList.contains(this.CLS_READY_CLASS);
    },

    _addEventListeners: function _addEventListeners() {
      var _this2 = this;

      if (this.IMPLEMENTATION_HOST) {
        window.addEventListener(this.CLS_EVENT, function (event) {
          return _this2._storeMeasurement(event.selector);
        });
      }
    },

    initialize: function initialize() {
      if (window.CustomEvent && window.fetch) {
        this._setHostAndPage();
        this._addEventListeners();
      }
    },

    /**
     * @param {string} selector
     */
    sendClsEventForSelector: function sendClsEventForSelector(selector) {
      var event = new CustomEvent(this.CLS_EVENT);
      event.selector = selector;
      window.dispatchEvent(event);
    },
  };
  mvfProteus.initialize();
}
